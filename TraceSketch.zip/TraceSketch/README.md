# TraceSketch

A tracing app for tablets. Pick a photo, show it full screen, put paper on the tablet and trace it.

## Features
- Open a photo from the gallery, shown full screen
- Detects colour photos and converts them to an outline (pencil sketch) automatically, offline
- Modes: Original / Black & White / Outline (with Detail and Line strength sliders)
- Brightness and Opacity sliders
- Pinch to zoom, drag to move, Rotate, Flip, Reset view
- Grid overlay (adjustable cells)
- Line colour: black, red, blue, or white on black
- Keep screen awake
- Lock button (top-right): freezes the picture. Press and hold the lock to unlock
- Save the converted image to Pictures/TraceSketch

## Get the APK
1. Push this whole folder to a GitHub repository (branch `main`).
2. Open the repository on GitHub, go to the **Actions** tab, and wait for **Build APK** to finish (about 3-5 minutes).
3. Open the finished run and download **TraceSketch-APK** from *Artifacts* (it is a zip containing `app-debug.apk`).
4. Copy the APK to your tablet and install it (allow "Install unknown apps" when asked).

You can also start a build by hand: Actions -> Build APK -> Run workflow.

Requires Android 10 or newer.
