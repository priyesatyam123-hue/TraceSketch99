package com.tracesketch.app

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * All the on-device (offline) image work: loading, colour detection,
 * black & white conversion and the "outline" (pencil sketch) conversion.
 */
object ImageProcessor {

    /** Loads a photo, fixes its rotation (EXIF) and shrinks it so its longest side is <= maxSide. */
    fun decode(resolver: ContentResolver, uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        val scale = min(1f, maxSide.toFloat() / max(bmp.width, bmp.height))
        if (scale < 1f) m.postScale(scale, scale)
        if (!m.isIdentity) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }

    /** True if the picture has real colour in it (false for black & white / grey photos and drawings). */
    fun isColour(px: IntArray): Boolean {
        val step = max(1, px.size / 20000)
        var coloured = 0
        var total = 0
        var i = 0
        while (i < px.size) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val spread = max(r, max(g, b)) - min(r, min(g, b))
            if (spread > 30) coloured++
            total++
            i += step
        }
        return coloured * 100 > total * 3 // more than 3% clearly coloured pixels
    }

    /** Greyscale values 0..255 (transparent areas are treated as white). */
    fun toGray(px: IntArray): IntArray {
        val out = IntArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            val a = (c ushr 24) and 0xFF
            var r = (c shr 16) and 0xFF
            var g = (c shr 8) and 0xFF
            var b = c and 0xFF
            if (a < 255) {
                r = (r * a + 255 * (255 - a)) / 255
                g = (g * a + 255 * (255 - a)) / 255
                b = (b * a + 255 * (255 - a)) / 255
            }
            out[i] = (r * 299 + g * 587 + b * 114) / 1000
        }
        return out
    }

    fun grayBitmap(gray: IntArray, w: Int, h: Int): Bitmap {
        val px = IntArray(gray.size)
        for (i in gray.indices) {
            val v = gray[i].coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /**
     * Pencil-sketch outline: invert, blur, colour-dodge. Flat areas turn white and
     * edges stay dark, which gives clean lines that are easy to trace.
     *
     * detail   0..100  low = bold, simple lines; high = thin, fine lines
     * strength 0..100  how dark / crisp the lines are
     */
    fun outline(gray: IntArray, w: Int, h: Int, detail: Int, strength: Int): Bitmap {
        val d = detail.coerceIn(0, 100) / 100f
        val s = strength.coerceIn(0, 100) / 100f

        // Low detail: smooth the photo first so small textures don't make noisy lines.
        val preRadius = ((1f - d) * 4f).roundToInt()
        val base = if (preRadius > 0) blur(gray, w, h, preRadius, 2) else gray

        val inverted = IntArray(base.size) { 255 - base[it] }
        val radius = (10f - 8f * d).roundToInt().coerceAtLeast(2)
        val blurred = blur(inverted, w, h, radius, 3)

        val gamma = 1.0 + s * 7.0
        // The extra "* 255 / 215" pushes very light greys to pure white, so flat areas come out clean.
        val lut = IntArray(256) {
            (255.0 * (it / 255.0).pow(gamma) * 255.0 / 215.0).roundToInt().coerceIn(0, 255)
        }

        val px = IntArray(base.size)
        for (i in base.indices) {
            val denom = 255 - blurred[i]
            val v = if (denom <= 0) 255 else min(255, base[i] * 255 / denom)
            val o = lut[v]
            px[i] = (0xFF shl 24) or (o shl 16) or (o shl 8) or o
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---- box blur (repeated 3x it is very close to a Gaussian blur) ----

    private fun blur(src: IntArray, w: Int, h: Int, r: Int, passes: Int): IntArray {
        var a = src.copyOf()
        val b = IntArray(src.size)
        repeat(passes) {
            boxH(a, b, w, h, r)
            boxV(b, a, w, h, r)
        }
        return a
    }

    private fun boxH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (i in -r..r) sum += src[row + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                dst[row + x] = sum / div
                val add = min(x + r + 1, w - 1)
                val sub = max(x - r, 0)
                sum += src[row + add] - src[row + sub]
            }
        }
    }

    private fun boxV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sum = 0
            for (i in -r..r) sum += src[i.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                dst[y * w + x] = sum / div
                val add = min(y + r + 1, h - 1)
                val sub = max(y - r, 0)
                sum += src[add * w + x] - src[sub * w + x]
            }
        }
    }
}
