package com.tracesketch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.min

/**
 * Shows the picture full screen. Supports pinch-zoom, drag, rotate, flip,
 * brightness, opacity, line colour, grid overlay and a lock that freezes everything.
 */
class TracingView(context: Context) : View(context) {

    private var bitmap: Bitmap? = null
    private var tintable = false // true for black&white / outline images (they can be recoloured)

    // user adjustments
    private var zoom = 1f
    private var tx = 0f
    private var ty = 0f
    private var quarterTurns = 0
    private var flipped = false

    /** 0 = black, 1 = red, 2 = blue, 3 = white lines on a black background */
    var lineMode = 0
        set(value) {
            field = value
            invalidate()
        }
    var brightness = 1f
        set(value) {
            field = value
            invalidate()
        }
    var opacity = 1f
        set(value) {
            field = value
            invalidate()
        }
    var showGrid = false
        set(value) {
            field = value
            invalidate()
        }
    var gridCells = 8
        set(value) {
            field = value
            invalidate()
        }

    /** When locked the picture ignores every touch, so nothing can move while you draw. */
    var locked = false

    private val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val gridPaint = Paint().apply {
        color = 0xB000A040.toInt()
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val newZoom = (zoom * detector.scaleFactor).coerceIn(0.2f, 15f)
                val change = newZoom / zoom
                val fx = detector.focusX - width / 2f
                val fy = detector.focusY - height / 2f
                tx = fx - (fx - tx) * change
                ty = fy - (fy - ty) * change
                zoom = newZoom
                invalidate()
                return true
            }
        }
    )

    // ---------- public controls ----------

    fun setImage(bmp: Bitmap, canTint: Boolean) {
        bitmap = bmp
        tintable = canTint
        invalidate()
    }

    fun resetView() {
        zoom = 1f
        tx = 0f
        ty = 0f
        quarterTurns = 0
        flipped = false
        invalidate()
    }

    fun rotate90() {
        quarterTurns = (quarterTurns + 1) % 4
        invalidate()
    }

    fun flipHorizontal() {
        flipped = !flipped
        invalidate()
    }

    /** The picture as it currently looks (colour, brightness, opacity, rotation, grid) at full size. */
    fun exportBitmap(): Bitmap? {
        val bmp = bitmap ?: return null
        val turned = quarterTurns % 2 == 1
        val ow = if (turned) bmp.height else bmp.width
        val oh = if (turned) bmp.width else bmp.height
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(backgroundColorNow())
        val m = buildMatrix(bmp, ow.toFloat(), oh.toFloat(), 1f, 0f, 0f)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = buildFilter()
        paint.alpha = (opacity * 255).toInt()
        c.drawBitmap(bmp, m, paint)
        if (showGrid) drawGrid(c, m, bmp)
        return out
    }

    // ---------- drawing ----------

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(backgroundColorNow())
        val bmp = bitmap ?: return
        val m = buildMatrix(bmp, width.toFloat(), height.toFloat(), zoom, tx, ty)
        imagePaint.colorFilter = buildFilter()
        imagePaint.alpha = (opacity * 255).toInt()
        canvas.drawBitmap(bmp, m, imagePaint)
        if (showGrid) drawGrid(canvas, m, bmp)
    }

    private fun backgroundColorNow(): Int {
        val base = if (tintable && lineMode == 3) 0f else 255f
        val v = (base * brightness).toInt().coerceIn(0, 255)
        return Color.rgb(v, v, v)
    }

    private fun buildMatrix(
        bmp: Bitmap, outW: Float, outH: Float, zoomValue: Float, offX: Float, offY: Float
    ): Matrix {
        val m = Matrix()
        m.postTranslate(-bmp.width / 2f, -bmp.height / 2f)
        if (flipped) m.postScale(-1f, 1f)
        m.postRotate(quarterTurns * 90f)
        val turned = quarterTurns % 2 == 1
        val rw = if (turned) bmp.height else bmp.width
        val rh = if (turned) bmp.width else bmp.height
        val fit = min(outW / rw, outH / rh)
        val s = fit * zoomValue
        m.postScale(s, s)
        m.postTranslate(outW / 2f + offX, outH / 2f + offY)
        return m
    }

    private fun buildFilter(): ColorMatrixColorFilter {
        val cm = ColorMatrix()
        if (tintable) {
            when (lineMode) {
                1 -> cm.postConcat(tintMatrix(0xFFD93025.toInt()))
                2 -> cm.postConcat(tintMatrix(0xFF1A4FD6.toInt()))
                3 -> cm.postConcat(
                    ColorMatrix(
                        floatArrayOf(
                            -1f, 0f, 0f, 0f, 255f,
                            0f, -1f, 0f, 0f, 255f,
                            0f, 0f, -1f, 0f, 255f,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            }
        }
        val b = ColorMatrix()
        b.setScale(brightness, brightness, brightness, 1f)
        cm.postConcat(b)
        return ColorMatrixColorFilter(cm)
    }

    /** Maps black -> the given colour and white -> white. */
    private fun tintMatrix(color: Int): ColorMatrix {
        val r = Color.red(color).toFloat()
        val g = Color.green(color).toFloat()
        val b = Color.blue(color).toFloat()
        return ColorMatrix(
            floatArrayOf(
                (255f - r) / 255f, 0f, 0f, 0f, r,
                0f, (255f - g) / 255f, 0f, 0f, g,
                0f, 0f, (255f - b) / 255f, 0f, b,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    private fun drawGrid(canvas: Canvas, m: Matrix, bmp: Bitmap) {
        val cell = bmp.width / gridCells.toFloat()
        if (cell < 1f) return
        val scale = m.mapRadius(1f)
        gridPaint.strokeWidth = 2.5f / scale
        canvas.save()
        canvas.concat(m)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        var x = 0f
        while (x <= w + 0.5f) {
            canvas.drawLine(x, 0f, x, h, gridPaint)
            x += cell
        }
        var y = 0f
        while (y <= h + 0.5f) {
            canvas.drawLine(0f, y, w, y, gridPaint)
            y += cell
        }
        canvas.restore()
    }

    // ---------- touch: drag + pinch zoom (ignored while locked) ----------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked || bitmap == null) return true // swallow touches while locked

        scaleDetector.onTouchEvent(e)

        val action = e.actionMasked
        val skip = if (action == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
        var sx = 0f
        var sy = 0f
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            sx += e.getX(i)
            sy += e.getY(i)
            n++
        }
        if (n == 0) return true
        val fx = sx / n
        val fy = sy / n

        when (action) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_POINTER_UP -> {
                lastX = fx
                lastY = fy
            }
            MotionEvent.ACTION_MOVE -> {
                tx += fx - lastX
                ty += fy - lastY
                lastX = fx
                lastY = fy
                invalidate()
            }
        }
        return true
    }
}
