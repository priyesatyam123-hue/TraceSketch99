package com.tracesketch.app

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.min

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_PICK = 101
private const val MAX_SIDE = 1800

/** A ScrollView that never grows taller than maxH, so the control panel can't cover the whole screen. */
class MaxHeightScrollView(ctx: Context) : ScrollView(ctx) {
    var maxH: Int = Int.MAX_VALUE

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(
            widthMeasureSpec,
            View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST)
        )
    }
}

class MainActivity : Activity() {

    private enum class Mode { ORIGINAL, BW, OUTLINE }

    private lateinit var root: FrameLayout
    private lateinit var tracing: TracingView
    private lateinit var hint: TextView
    private lateinit var panelScroll: MaxHeightScrollView
    private lateinit var menuBtn: TextView
    private lateinit var lockBtn: TextView
    private lateinit var outlineControls: LinearLayout
    private lateinit var gridControls: LinearLayout
    private lateinit var gridChip: TextView
    private lateinit var awakeChip: TextView
    private val modeChips = HashMap<Mode, TextView>()
    private val colourChips = ArrayList<TextView>()

    private val executor = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var source: Bitmap? = null
    private var grayPixels: IntArray? = null
    private var grayBitmap: Bitmap? = null
    private var imgW = 0
    private var imgH = 0

    private var mode = Mode.ORIGINAL
    private var detail = 60
    private var strength = 45
    @Volatile
    private var generation = 0

    private var locked = false
    private var panelOpen = true
    private var keepAwake = true
    private var gridOn = false

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val attrs = window.attributes
        attrs.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = attrs

        buildUi()
        setContentView(root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goImmersive()
        updateModeUi()
        updateColourUi()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        layoutPanel()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            data?.data?.let { loadPhoto(it) }
        }
    }

    private fun goImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            val flags = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            window.decorView.systemUiVisibility = flags
        }
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.WHITE)

        tracing = TracingView(this)
        root.addView(tracing, FrameLayout.LayoutParams(MATCH, MATCH))

        hint = TextView(this).apply {
            text = "Tap the menu button  ☰  then \"Open photo\" to start"
            textSize = 18f
            setTextColor(0xFF666666.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        root.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        // ----- control panel -----
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = round(0xF2202124.toInt(), 20)
        }

        // Row 1: open photo + conversion mode
        val openChip = chip("📂  Open photo") { pickPhoto() }
        openChip.background = pill(0xFF1A73E8.toInt())
        for (m in Mode.values()) {
            val label = when (m) {
                Mode.ORIGINAL -> "Original"
                Mode.BW -> "Black & White"
                Mode.OUTLINE -> "Outline (sketch)"
            }
            modeChips[m] = chip(label) { setMode(m) }
        }
        val row1 = ArrayList<View>()
        row1.add(openChip)
        for (m in Mode.values()) row1.add(modeChips[m]!!)
        panel.addView(chipRow(row1))

        // Outline-only sliders
        outlineControls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outlineControls.addView(slider("Detail", 0, 100, detail, "%") {
            detail = it
            if (mode == Mode.OUTLINE) runOutline()
        })
        outlineControls.addView(slider("Line strength", 0, 100, strength, "%") {
            strength = it
            if (mode == Mode.OUTLINE) runOutline()
        })
        panel.addView(outlineControls)

        // Brightness / opacity
        panel.addView(slider("Brightness", 10, 100, 100, "%") { tracing.brightness = it / 100f })
        panel.addView(slider("Opacity", 10, 100, 100, "%") { tracing.opacity = it / 100f })

        // Grid / rotate / flip / reset
        gridChip = chip("Grid") { toggleGrid() }
        val rotateChip = chip("⟳ Rotate") { tracing.rotate90() }
        val flipChip = chip("⇋ Flip") { tracing.flipHorizontal() }
        val resetChip = chip("Reset view") { tracing.resetView() }
        panel.addView(chipRow(listOf(gridChip, rotateChip, flipChip, resetChip)))

        gridControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        gridControls.addView(slider("Grid cells", 2, 30, 8, "") { tracing.gridCells = it })
        panel.addView(gridControls)

        // Line colour
        val colourRow = ArrayList<View>()
        colourRow.add(TextView(this).apply {
            text = "Line colour"
            setTextColor(0xFFDADCE0.toInt())
            textSize = 13f
            setPadding(0, 0, dp(10), 0)
        })
        val colourNames = listOf("Black", "Red", "Blue", "White on black")
        for ((index, name) in colourNames.withIndex()) {
            val c = chip(name) {
                tracing.lineMode = index
                updateColourUi()
            }
            colourChips.add(c)
            colourRow.add(c)
        }
        val colourScroll = chipRow(colourRow)
        (colourScroll.layoutParams as LinearLayout.LayoutParams).topMargin = dp(6)
        panel.addView(colourScroll)

        // Keep awake / save
        awakeChip = chip("Keep screen awake") { toggleAwake() }
        val saveChip = chip("💾 Save image") { savePicture() }
        updateAwakeUi()
        val lastRow = chipRow(listOf(awakeChip, saveChip))
        (lastRow.layoutParams as LinearLayout.LayoutParams).topMargin = dp(6)
        panel.addView(lastRow)

        panelScroll = MaxHeightScrollView(this)
        panelScroll.addView(panel, ViewGroup.LayoutParams(MATCH, WRAP))
        layoutPanel()
        root.addView(panelScroll)

        // ----- corner buttons -----
        menuBtn = cornerButton("☰") {
            panelOpen = !panelOpen
            panelScroll.visibility = if (panelOpen) View.VISIBLE else View.GONE
        }
        root.addView(menuBtn, cornerParams(Gravity.TOP or Gravity.START))

        lockBtn = cornerButton("🔓") {
            if (!locked) {
                setLocked(true)
            } else {
                toast("Locked. Press and hold the lock to unlock.")
            }
        }
        lockBtn.setOnLongClickListener {
            if (locked) {
                setLocked(false)
                true
            } else {
                false
            }
        }
        root.addView(lockBtn, cornerParams(Gravity.TOP or Gravity.END))
    }

    private fun layoutPanel() {
        val dm = resources.displayMetrics
        val w = min(dm.widthPixels - dp(24), dp(620))
        val lp = FrameLayout.LayoutParams(w, WRAP, Gravity.BOTTOM or Gravity.START)
        lp.setMargins(dp(12), dp(12), dp(12), dp(12))
        panelScroll.layoutParams = lp
        panelScroll.maxH = (dm.heightPixels * 0.6f).toInt()
    }

    private fun cornerParams(gravity: Int): FrameLayout.LayoutParams {
        val lp = FrameLayout.LayoutParams(dp(56), dp(56), gravity)
        lp.setMargins(dp(16), dp(16), dp(16), dp(16))
        return lp
    }

    private fun cornerButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC202124.toInt())
            }
            setOnClickListener { onClick() }
        }
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label
        v.setTextColor(Color.WHITE)
        v.textSize = 14f
        v.gravity = Gravity.CENTER
        v.setPadding(dp(14), dp(9), dp(14), dp(9))
        v.background = pill(0xFF3C4043.toInt())
        v.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.rightMargin = dp(8)
        v.layoutParams = lp
        return v
    }

    private fun setChipSelected(v: TextView, selected: Boolean) {
        v.background = pill(if (selected) 0xFF1A73E8.toInt() else 0xFF3C4043.toInt())
    }

    private fun chipRow(chips: List<View>): HorizontalScrollView {
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.HORIZONTAL
        inner.gravity = Gravity.CENTER_VERTICAL
        for (c in chips) inner.addView(c)
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(inner)
        scroll.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        return scroll
    }

    private fun slider(
        label: String, lo: Int, hi: Int, initial: Int, unit: String, onChange: (Int) -> Unit
    ): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(2), 0, dp(2))

        val name = TextView(this)
        name.text = label
        name.setTextColor(0xFFDADCE0.toInt())
        name.textSize = 13f
        row.addView(name, LinearLayout.LayoutParams(dp(104), WRAP))

        val valueText = TextView(this)
        valueText.text = "$initial$unit"
        valueText.setTextColor(0xFF9AA0A6.toInt())
        valueText.textSize = 12f
        valueText.gravity = Gravity.END

        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = initial - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val value = progress + lo
                    valueText.text = "$value$unit"
                    onChange(value)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        row.addView(bar, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(valueText, LinearLayout.LayoutParams(dp(48), WRAP))
        return row
    }

    private fun pill(color: Int): GradientDrawable = round(color, 18)

    private fun round(color: Int, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        return d
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ actions

    private fun setLocked(value: Boolean) {
        locked = value
        tracing.locked = value
        menuBtn.visibility = if (value) View.GONE else View.VISIBLE
        panelScroll.visibility = if (!value && panelOpen) View.VISIBLE else View.GONE
        lockBtn.text = if (value) "🔒" else "🔓"
        lockBtn.alpha = if (value) 0.45f else 1f
        if (value) toast("Locked. Press and hold the lock to unlock.")
    }

    private fun toggleGrid() {
        gridOn = !gridOn
        tracing.showGrid = gridOn
        setChipSelected(gridChip, gridOn)
        gridControls.visibility = if (gridOn) View.VISIBLE else View.GONE
    }

    private fun toggleAwake() {
        keepAwake = !keepAwake
        if (keepAwake) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        updateAwakeUi()
    }

    private fun updateAwakeUi() {
        setChipSelected(awakeChip, keepAwake)
    }

    private fun updateColourUi() {
        for ((i, c) in colourChips.withIndex()) setChipSelected(c, i == tracing.lineMode)
    }

    private fun updateModeUi() {
        for (m in Mode.values()) setChipSelected(modeChips[m]!!, m == mode)
        outlineControls.visibility = if (mode == Mode.OUTLINE) View.VISIBLE else View.GONE
    }

    private fun pickPhoto() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, REQ_PICK)
    }

    private fun loadPhoto(uri: Uri) {
        toast("Loading photo...")
        executor.execute {
            val bmp = try {
                ImageProcessor.decode(contentResolver, uri, MAX_SIDE)
            } catch (e: Exception) {
                null
            }
            if (bmp == null) {
                ui.post { toast("Couldn't open that image") }
                return@execute
            }
            val w = bmp.width
            val h = bmp.height
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            val colour = ImageProcessor.isColour(px)
            val gray = ImageProcessor.toGray(px)
            val grayBmp = ImageProcessor.grayBitmap(gray, w, h)

            ui.post {
                source = bmp
                grayPixels = gray
                grayBitmap = grayBmp
                imgW = w
                imgH = h
                hint.visibility = View.GONE
                tracing.resetView()
                mode = if (colour) Mode.OUTLINE else Mode.ORIGINAL
                toast(
                    if (colour) "Colour photo detected, converted to an outline"
                    else "Already black & white, ready to trace"
                )
                applyMode()
            }
        }
    }

    private fun setMode(m: Mode) {
        if (source == null) {
            toast("Open a photo first")
            return
        }
        mode = m
        applyMode()
    }

    private fun applyMode() {
        val src = source ?: return
        updateModeUi()
        when (mode) {
            Mode.ORIGINAL -> tracing.setImage(src, false)
            Mode.BW -> grayBitmap?.let { tracing.setImage(it, true) }
            Mode.OUTLINE -> runOutline()
        }
    }

    /** Runs the sketch conversion in the background; only the newest request is shown. */
    private fun runOutline() {
        val g = grayPixels ?: return
        val gen = ++generation
        val d = detail
        val s = strength
        val w = imgW
        val h = imgH
        executor.execute {
            if (gen != generation) return@execute
            val bmp = ImageProcessor.outline(g, w, h, d, s)
            ui.post {
                if (gen == generation && mode == Mode.OUTLINE) tracing.setImage(bmp, true)
            }
        }
    }

    private fun savePicture() {
        val bmp = tracing.exportBitmap()
        if (bmp == null) {
            toast("Open a photo first")
            return
        }
        executor.execute {
            val ok = try {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "tracesketch_${System.currentTimeMillis()}.png")
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                values.put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/TraceSketch"
                )
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    false
                } else {
                    contentResolver.openOutputStream(uri)?.use {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                    } ?: false
                }
            } catch (e: Exception) {
                false
            }
            ui.post { toast(if (ok) "Saved to Pictures/TraceSketch" else "Couldn't save the image") }
        }
    }
}
